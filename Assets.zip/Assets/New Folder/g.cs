using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class g : MonoBehaviour
{
    // Start is called before the first frame update
    public void BT()
    {
        SceneManager.LoadScene("G");
    }
}
