namespace Dan.Main
{
    public static class Leaderboards
    {
        public static LeaderboardReference owo = new LeaderboardReference("cd73bca42bcaf3e1c0596e6c1366e592be0035724deafe58032d2f731c930828af3304225dec345abadd39bece6d4763c0386866d6211bf5a44f861b0e8a9c775e62de077fab1c722a535ad80b");
    }
}
